---
title: right-click-project
---

Right-click a folder in the Project window's folder list or anywhere in the Project window's preview pane.