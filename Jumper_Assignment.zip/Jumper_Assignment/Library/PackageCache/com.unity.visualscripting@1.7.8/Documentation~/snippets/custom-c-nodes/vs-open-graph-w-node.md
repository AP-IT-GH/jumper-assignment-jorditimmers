---
title: open-graph-w-node
---

[Open a Script Graph](../../vs-open-graph-edit.md) where you've already added your node.