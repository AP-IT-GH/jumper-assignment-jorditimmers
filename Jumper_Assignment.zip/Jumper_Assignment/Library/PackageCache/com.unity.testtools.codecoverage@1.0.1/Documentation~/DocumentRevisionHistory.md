# Document revision history

|Date|Reason|
|:---|:---|
|Jun 16, 2021|<li>Added **Ignoring tests for Code Coverage** section.<li>Matches package version *1.0.1*.|
|Mar 09, 2021|<li>Added **Quickstart** guide.<li>Matches package version *1.0.0*.|
